$(document).ready(function(){
"use strict";
$("#pagenav a[href*='FuseAction=Security.ExistingUserLogin']").remove();
});// JavaScript Document